# Car Racing Game — Java Swing

A desktop racing game built with Java Swing/AWT (no external libraries).

## Features
- Blue player car with racing stripe and YOU label
- Traffic cars, road movement, collision and Game Over/restart
- Easy, Medium, Hard and Ultra Hard modes (keys 1–4)
- Ultra Hard surprise dummy traffic
- SPACE to jump over a nearby car, limited to 3 jumps per race
- City-side buildings, windows, streetlights and cheering spectators
- Score and best score during the current app session

## Run in VS Code
1. Install a JDK and the VS Code Extension Pack for Java.
2. Open this whole folder in VS Code.
3. Open `src/Main.java` and click Run above `main`, or use the terminal:

   ```cmd
   cd src
   javac Main.java GamePanel.java Car.java TrafficCar.java
   java Main
   ```

If `javac` is not recognized, temporarily add your JDK `bin` folder to the current terminal PATH. For the JDK shown in the setup conversation:

```cmd
set "PATH=C:\Program Files\Java\jdk-27.0.1.0.3\bin;%PATH%"
```

## Controls
- Left / Right arrows or A / D: steer
- SPACE: start/restart, or jump when a traffic car is close ahead
- 1: Easy, 2: Medium, 3: Hard, 4: Ultra Hard
