import java.awt.*;
import java.util.concurrent.ThreadLocalRandom;

public class TrafficCar extends Car {
    public boolean dummy;

    private static final Color[] COLORS = {
        new Color(235, 65, 65), new Color(255, 155, 45),
        new Color(220, 70, 190), new Color(240, 240, 245),
        new Color(60, 210, 180), new Color(245, 205, 60)
    };

    public TrafficCar(int x, int y, boolean dummy) {
        super(x, y, COLORS[ThreadLocalRandom.current().nextInt(COLORS.length)], false);
        this.dummy = dummy;
    }
}
