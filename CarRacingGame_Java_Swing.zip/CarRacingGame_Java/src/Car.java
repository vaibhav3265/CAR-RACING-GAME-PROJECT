import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Car {
    int x, y;
    final int width = 44;
    final int height = 76;
    Color color;
    boolean player;

    public Car(int x, int y, Color color, boolean player) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.player = player;
    }

    public Rectangle getBounds() {
        // Slightly inset collision box makes collisions feel fairer.
        return new Rectangle(x + 5, y + 5, width - 10, height - 10);
    }

    public void draw(Graphics2D g, int lift) {
        int drawY = y - lift;
        Graphics2D c = (Graphics2D) g.create();
        c.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Wheels
        c.setColor(new Color(18, 18, 22));
        c.fillRoundRect(x - 4, drawY + 12, 10, 20, 4, 4);
        c.fillRoundRect(x + width - 6, drawY + 12, 10, 20, 4, 4);
        c.fillRoundRect(x - 4, drawY + 47, 10, 20, 4, 4);
        c.fillRoundRect(x + width - 6, drawY + 47, 10, 20, 4, 4);

        // Body
        c.setColor(color);
        c.fill(new RoundRectangle2D.Float(x, drawY, width, height, 13, 13));

        // Side highlight
        c.setColor(color.brighter());
        c.fillRoundRect(x + 4, drawY + 17, 4, 40, 3, 3);

        // Front windshield
        c.setColor(new Color(150, 222, 245));
        c.fillRoundRect(x + 8, drawY + 13, width - 16, 18, 6, 6);

        // Rear windshield
        c.setColor(new Color(90, 160, 190));
        c.fillRoundRect(x + 8, drawY + 45, width - 16, 14, 5, 5);

        // Racing stripe and YOU label on player's blue car
        if (player) {
            c.setColor(new Color(235, 250, 255));
            c.fillRect(x + 20, drawY + 4, 4, 8);
            c.fillRect(x + 20, drawY + 33, 4, 10);
            c.setFont(new Font("Arial", Font.BOLD, 8));
            c.drawString("YOU", x + 12, drawY + 42);
        }

        // Headlights / tail lights
        c.setColor(new Color(255, 245, 130));
        c.fillRoundRect(x + 4, drawY + 3, 10, 5, 3, 3);
        c.fillRoundRect(x + width - 14, drawY + 3, 10, 5, 3, 3);
        c.setColor(new Color(255, 55, 65));
        c.fillRect(x + 5, drawY + height - 6, 9, 4);
        c.fillRect(x + width - 14, drawY + height - 6, 9, 4);

        c.dispose();
    }
}
