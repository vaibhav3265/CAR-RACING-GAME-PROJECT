import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {
    private static final int W = 520, H = 780;
    private static final int ROAD_X = 100, ROAD_W = 320;
    private static final int PLAYER_Y = 625;
    private static final int[] LANES = {128, 205, 282, 359};

    private final Timer timer = new Timer(16, this);
    private final Random random = new Random();
    private final ArrayList<TrafficCar> traffic = new ArrayList<>();
    private final ArrayList<ParticlePerson> people = new ArrayList<>();

    private Car player = new Car(238, PLAYER_Y, new Color(0, 125, 255), true);
    private boolean started = false, running = false, gameOver = false;
    private boolean leftPressed = false, rightPressed = false;
    private String difficulty = "MEDIUM";

    private int score = 0, highScore = 0, speed = 5, spawnDelay = 72;
    private int spawnTick = 0, roadOffset = 0, sceneryOffset = 0;
    private int jumpsRemaining = 3, jumpFrames = 0, jumpCooldown = 0;
    private int ultraTicks = 0, nextDummyAt = 850;
    private long lastFrameNanos = System.nanoTime();

    public GamePanel() {
        setPreferredSize(new Dimension(W, H));
        setBackground(new Color(32, 135, 54));
        setFocusable(true);
        setDoubleBuffered(true);
        setupKeys();
        seedPeople();
        timer.start();
    }

    private void setupKeys() {
        bind("LEFT", "left", () -> leftPressed = true);
        bind("released LEFT", "leftUp", () -> leftPressed = false);
        bind("RIGHT", "right", () -> rightPressed = true);
        bind("released RIGHT", "rightUp", () -> rightPressed = false);
        bind("A", "a", () -> leftPressed = true);
        bind("released A", "aUp", () -> leftPressed = false);
        bind("D", "d", () -> rightPressed = true);
        bind("released D", "dUp", () -> rightPressed = false);
        bind("SPACE", "space", this::spaceAction);
        bind("1", "easy", () -> chooseDifficulty("EASY"));
        bind("2", "medium", () -> chooseDifficulty("MEDIUM"));
        bind("3", "hard", () -> chooseDifficulty("HARD"));
        bind("4", "ultra", () -> chooseDifficulty("ULTRA HARD"));
        bind("ENTER", "enter", () -> { if (!started || gameOver) startGame(); });
    }

    private void bind(String keyStroke, String name, Runnable action) {
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(keyStroke), name);
        getActionMap().put(name, new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { action.run(); }
        });
    }

    private void spaceAction() {
        if (!started || gameOver) startGame();
        else if (running) tryJump();
    }

    private void chooseDifficulty(String mode) {
        difficulty = mode;
        if (running) applyDifficulty();
        repaint();
    }

    private void applyDifficulty() {
        switch (difficulty) {
            case "EASY": speed = 4; spawnDelay = 88; break;
            case "MEDIUM": speed = 5; spawnDelay = 70; break;
            case "HARD": speed = 7; spawnDelay = 52; break;
            default: speed = 8; spawnDelay = 43; break;
        }
    }

    private void startGame() {
        score = 0;
        traffic.clear();
        player.x = W / 2 - player.width / 2;
        player.y = PLAYER_Y;
        jumpsRemaining = 3;
        jumpFrames = 0;
        jumpCooldown = 0;
        spawnTick = 0;
        ultraTicks = 0;
        nextDummyAt = 850;
        roadOffset = 0;
        applyDifficulty();
        started = true;
        running = true;
        gameOver = false;
        leftPressed = rightPressed = false;
        lastFrameNanos = System.nanoTime();
        requestFocusInWindow();
        repaint();
    }

    private void tryJump() {
        if (jumpFrames > 0 || jumpCooldown > 0 || jumpsRemaining <= 0) return;
        TrafficCar target = null;
        int bestDistance = Integer.MAX_VALUE;
        for (TrafficCar car : traffic) {
            int horizontal = Math.abs((player.x + player.width / 2) - (car.x + car.width / 2));
            int distance = player.y - (car.y + car.height);
            if (horizontal < 32 && distance >= -8 && distance < 160 && distance < bestDistance) {
                target = car;
                bestDistance = distance;
            }
        }
        if (target != null) {
            jumpFrames = 54;
            jumpCooldown = 90;
            jumpsRemaining--;
            score += 10;
        }
    }

    @Override public void actionPerformed(ActionEvent e) {
        long now = System.nanoTime();
        double dt = Math.min(2.0, (now - lastFrameNanos) / 16_000_000.0);
        lastFrameNanos = now;
        if (running) updateGame(dt);
        repaint();
    }

    private void updateGame(double dt) {
        int movement = Math.max(5, (int)(7 * dt));
        if (leftPressed) player.x -= movement;
        if (rightPressed) player.x += movement;
        player.x = Math.max(ROAD_X + 10, Math.min(ROAD_X + ROAD_W - player.width - 10, player.x));

        roadOffset = (roadOffset + (int)(speed * dt)) % 80;
        sceneryOffset = (sceneryOffset + (int)(speed * dt)) % 130;
        if (jumpCooldown > 0) jumpCooldown--;
        if (jumpFrames > 0) jumpFrames--;

        spawnTick++;
        if (spawnTick >= spawnDelay) {
            spawnTick = 0;
            int lane = LANES[random.nextInt(LANES.length)];
            traffic.add(new TrafficCar(lane, -90, false));
        }

        if (difficulty.equals("ULTRA HARD")) {
            ultraTicks += speed;
            if (ultraTicks >= nextDummyAt) {
                // Surprise dummy cars appear ahead, but never directly on top of the player.
                int lane = LANES[random.nextInt(LANES.length)];
                if (Math.abs(lane - player.x) > 45) traffic.add(new TrafficCar(lane, -100, true));
                else traffic.add(new TrafficCar(LANES[(random.nextInt(LANES.length))], -150, true));
                nextDummyAt += 650 + random.nextInt(500);
            }
        }

        Iterator<TrafficCar> it = traffic.iterator();
        while (it.hasNext()) {
            TrafficCar car = it.next();
            car.y += Math.max(2, (int)(speed * dt));
            if (car.y > H + 10) {
                it.remove();
                score += 5;
                continue;
            }
            if (jumpFrames <= 0 && player.getBounds().intersects(car.getBounds())) {
                endGame();
                return;
            }
        }
        score += Math.max(0, (int)(dt * 0.15));
    }

    private void endGame() {
        running = false;
        gameOver = true;
        highScore = Math.max(highScore, score);
        leftPressed = rightPressed = false;
    }

    private void seedPeople() {
        for (int i = 0; i < 14; i++) people.add(new ParticlePerson(i % 2 == 0 ? 18 : W - 30, i * 65));
    }

    @Override protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawScenery(g);
        drawRoad(g);

        if (started) {
            for (TrafficCar car : traffic) {
                car.draw(g, 0);
                if (car.dummy) drawDummyMark(g, car);
            }
            int lift = jumpFrames > 0 ? (int)(Math.sin((54 - jumpFrames) * Math.PI / 54.0) * 72) : 0;
            if (lift > 0) {
                g.setColor(new Color(0, 0, 0, 65));
                g.fillOval(player.x - 5, player.y + 50, 56, 24);
            }
            player.draw(g, lift);
            drawHUD(g);
            if (gameOver) drawGameOver(g);
        } else {
            drawStartScreen(g);
        }
        g.dispose();
    }

    private void drawRoad(Graphics2D g) {
        g.setColor(new Color(53, 55, 61));
        g.fillRect(ROAD_X, 0, ROAD_W, H);
        g.setColor(new Color(235, 235, 235));
        g.fillRect(ROAD_X, 0, 5, H);
        g.fillRect(ROAD_X + ROAD_W - 5, 0, 5, H);
        g.setColor(new Color(255, 210, 45));
        for (int y = -80 + roadOffset; y < H; y += 80) {
            g.fillRoundRect(ROAD_X + ROAD_W / 2 - 3, y, 6, 42, 4, 4);
        }
        // Roadside dashed edge markers
        g.setColor(new Color(245, 245, 245, 130));
        for (int y = -60 + roadOffset; y < H; y += 60) {
            g.fillRect(ROAD_X + 14, y, 3, 24);
            g.fillRect(ROAD_X + ROAD_W - 17, y, 3, 24);
        }
    }

    private void drawScenery(Graphics2D g) {
        g.setColor(new Color(39, 135, 54));
        g.fillRect(0, 0, W, H);

        for (int y = -130 + sceneryOffset; y < H; y += 260) {
            drawBuilding(g, 8, y + 25, 70, 145, new Color(94, 105, 133));
            drawBuilding(g, 442, y + 95, 66, 130, new Color(127, 93, 111));
            drawStreetlight(g, 83, y + 45);
            drawStreetlight(g, 428, y + 175);
        }

        // Cheering spectators on both sides
        for (int i = 0; i < people.size(); i++) {
            ParticlePerson p = people.get(i);
            int y = Math.floorMod(p.y + sceneryOffset, H + 70) - 35;
            drawPerson(g, p.x, y, i);
        }
    }

    private void drawBuilding(Graphics2D g, int x, int y, int w, int h, Color color) {
        g.setColor(color);
        g.fillRoundRect(x, y, w, h, 5, 5);
        g.setColor(new Color(255, 221, 100));
        for (int wy = y + 12; wy < y + h - 8; wy += 25) {
            for (int wx = x + 10; wx < x + w - 8; wx += 22) {
                g.fillRect(wx, wy, 10, 12);
            }
        }
        g.setColor(new Color(45, 48, 60));
        g.fillRect(x + w / 2 - 8, y + h - 25, 16, 25);
    }

    private void drawStreetlight(Graphics2D g, int x, int y) {
        g.setColor(new Color(45, 48, 52));
        g.fillRect(x, y, 4, 52);
        g.drawLine(x + 2, y, x + 14, y - 8);
        g.setColor(new Color(255, 244, 160));
        g.fillOval(x + 8, y - 14, 15, 13);
    }

    private void drawPerson(Graphics2D g, int x, int y, int i) {
        Color[] shirts = {new Color(255, 85, 85), new Color(255, 220, 65),
                          new Color(70, 210, 240), new Color(245, 245, 245),
                          new Color(220, 100, 230)};
        g.setColor(new Color(245, 195, 150));
        g.fillOval(x + 3, y, 10, 10);
        g.setColor(shirts[i % shirts.length]);
        g.fillRoundRect(x + 1, y + 10, 14, 18, 5, 5);
        g.setColor(new Color(245, 195, 150));
        int wave = (i % 2 == 0) ? -7 : 7;
        g.drawLine(x + 3, y + 14, x - 3, y + wave);
        g.drawLine(x + 13, y + 14, x + 20, y - 7);
        g.setColor(Color.BLACK);
        g.drawLine(x + 4, y + 28, x + 3, y + 36);
        g.drawLine(x + 11, y + 28, x + 13, y + 36);
    }

    private void drawDummyMark(Graphics2D g, TrafficCar car) {
        g.setColor(Color.BLACK);
        g.fillRoundRect(car.x + 5, car.y + 31, 34, 13, 4, 4);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 8));
        g.drawString("DUMMY", car.x + 7, car.y + 40);
    }

    private void drawHUD(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 155));
        g.fillRoundRect(12, 10, 190, 76, 14, 14);
        g.fillRoundRect(W - 160, 10, 148, 76, 14, 14);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 17));
        g.drawString("SCORE  " + score, 25, 36);
        g.setFont(new Font("Arial", Font.PLAIN, 13));
        g.drawString("BEST   " + highScore, 25, 59);
        g.drawString("JUMPS  " + jumpsRemaining + " / 3", W - 148, 35);
        g.drawString(difficulty, W - 148, 59);
        g.setFont(new Font("Arial", Font.PLAIN, 12));
        g.drawString("← → / A D: steer    SPACE: jump", 145, H - 16);
    }

    private void drawStartScreen(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRoundRect(42, 190, W - 84, 385, 25, 25);
        g.setColor(new Color(70, 190, 255));
        g.setFont(new Font("Arial", Font.BOLD, 34));
        g.drawString("CAR RACING", 145, 245);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString("Dodge traffic. Jump to overtake!", 111, 282);
        g.setFont(new Font("Arial", Font.PLAIN, 15));
        g.drawString("LEFT / RIGHT or A / D  -  Steer", 112, 325);
        g.drawString("SPACE  -  Jump over a nearby car", 103, 355);
        g.drawString("Only 3 jumps per race", 160, 385);
        g.drawString("Choose difficulty with keys 1 - 4", 116, 423);
        g.setColor(new Color(110, 220, 255));
        g.drawString("1 Easy     2 Medium     3 Hard     4 Ultra Hard", 74, 455);
        g.setColor(new Color(255, 230, 85));
        g.setFont(new Font("Arial", Font.BOLD, 21));
        g.drawString("PRESS SPACE TO START", 108, 510);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.PLAIN, 12));
        g.drawString("Ultra Hard includes surprise dummy cars!", 113, 545);
    }

    private void drawGameOver(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 190));
        g.fillRoundRect(65, 250, W - 130, 260, 24, 24);
        g.setColor(new Color(255, 75, 85));
        g.setFont(new Font("Arial", Font.BOLD, 36));
        g.drawString("GAME OVER", 150, 315);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Score: " + score, 205, 365);
        g.drawString("Best: " + highScore, 205, 400);
        g.setColor(new Color(255, 230, 80));
        g.setFont(new Font("Arial", Font.BOLD, 17));
        g.drawString("Press SPACE to restart", 143, 455);
    }

    private static class ParticlePerson {
        int x, y;
        ParticlePerson(int x, int y) { this.x = x; this.y = y; }
    }
}
